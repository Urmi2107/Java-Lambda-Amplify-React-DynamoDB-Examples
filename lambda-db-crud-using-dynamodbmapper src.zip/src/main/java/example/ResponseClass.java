/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	STORAGE_FRIENDSDB_ARN
	STORAGE_FRIENDSDB_NAME
	STORAGE_FRIENDSDB_STREAMARN
Amplify Params - DO NOT EDIT */

package example;
        
     public class ResponseClass {
        private String id;
        private String name;
        private String features;
        private Integer affinity;

        public String getId() {
            return id;
        }
        public void setId(String id) {
            this.id = id;
        }
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public String getFeatures() {
            return features;
        }
        public void setFeatures(String features) {
            this.features = features;
        }
        public Integer getAffinity() {
            return affinity;
        }
        public void setAffinity(Integer affinity) {
            this.affinity = affinity;
        }
        public ResponseClass(String id, String name, String features, Integer affinity) {
            this.id = id;
            this.name = name;
            this.features = features;
            this.affinity = affinity;
        }
        public ResponseClass() {
        }
        
    }