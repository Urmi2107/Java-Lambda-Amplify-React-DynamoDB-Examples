/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	STORAGE_FRIENDSDB_ARN
	STORAGE_FRIENDSDB_NAME
	STORAGE_FRIENDSDB_STREAMARN
Amplify Params - DO NOT EDIT */

package example;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.google.gson.Gson;

import example.DynamoDBMappers.FriendsTableEntity;

public class LambdaRequestHandler{   
	static String getAlphaNumericString(int n){
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
				+ "0123456789"
				+ "abcdefghijklmnopqrstuvxyz";
		StringBuilder sb = new StringBuilder(n);
		for (int i = 0; i < n; i++) {
		int index
			= (int)(AlphaNumericString.length()
			* Math.random());
		sb.append(AlphaNumericString
			.charAt(index));
		}
		
		return sb.toString();
	} 
    public APIGatewayProxyResponseEvent handleRequest(APIGatewayProxyRequestEvent request, Context context){
		APIGatewayProxyResponseEvent apiGatewayProxyResponseEvent=new APIGatewayProxyResponseEvent();
		DynamoDBMapper dynamoDBMapper=new DynamoDBMapper(AmazonDynamoDBClientBuilder.standard().build());
		Gson gson=new Gson();
		ModelMapper mapper=new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Map<String , String>headers=new HashMap<>();
        headers.put("Access-Control-Allow-Headers", "Content-Type");
        headers.put("Access-Control-Allow-Origin", "*");    
        headers.put("Access-Control-Allow-Methods", "OPTIONS,POST,GET,DELETE,PUT");
		if(request.getHttpMethod().equals("GET") && request.getPath().equals("/friends")){
			AmazonDynamoDB amazonDynamoDB=AmazonDynamoDBClientBuilder.standard().build();
			ScanResult scanResult = amazonDynamoDB.scan(new ScanRequest().withTableName(System.getenv("STORAGE_FRIENDSDB_NAME")));
			List<ResponseClass> movies=scanResult.getItems().stream().map(
				item->new ResponseClass(
					item.get("id").getS(),
					item.get("name").getS(),
					item.get("features").getS(),
					Integer.parseInt(item.get("affinity").getN())
				)
			)
			.collect(Collectors.toList());
			return apiGatewayProxyResponseEvent.withBody(gson.toJson(movies)).withHeaders(headers).withStatusCode(200);
		}
		if(request.getHttpMethod().equals("POST") && request.getPath().equals("/friends")){
			RequestClass requestClass=gson.fromJson(request.getBody(), RequestClass.class);
			FriendsTableEntity entity = mapper.map(requestClass, FriendsTableEntity.class);
			entity.setId(getAlphaNumericString(20));
			dynamoDBMapper.save(entity);
			ResponseClass response = mapper.map(entity, ResponseClass.class);
			return apiGatewayProxyResponseEvent.withBody(gson.toJson(response)).withHeaders(headers).withStatusCode(200);
		}
		if(request.getHttpMethod().equals("PUT") && request.getPath().equals("/friends")){
			RequestClass requestClass=gson.fromJson(request.getBody(), RequestClass.class);
			FriendsTableEntity entity = mapper.map(requestClass, FriendsTableEntity.class);
			dynamoDBMapper.save(entity);
			ResponseClass response = mapper.map(entity, ResponseClass.class);
			return apiGatewayProxyResponseEvent.withBody(gson.toJson(response)).withHeaders(headers).withStatusCode(200);
		}
		if(request.getHttpMethod().equals("DELETE") && request.getPath().equals("/friends")){
			RequestClass requestClass=gson.fromJson(request.getBody(), RequestClass.class);
			FriendsTableEntity entity = mapper.map(requestClass, FriendsTableEntity.class);
			dynamoDBMapper.delete(entity);
			return apiGatewayProxyResponseEvent.withBody(gson.toJson(entity.getName()+" is not your friend anymore"))
			.withHeaders(headers).withStatusCode(200);
		}
		if(request.getHttpMethod().equals("GET") && request.getResource().equals("/friends/{proxy+}")){
			String friendId=request.getPathParameters().get("proxy");
			FriendsTableEntity entity = dynamoDBMapper.load(FriendsTableEntity.class, friendId);
			ResponseClass response = mapper.map(entity, ResponseClass.class);
			return apiGatewayProxyResponseEvent.withBody(gson.toJson(response)).withHeaders(headers).withStatusCode(200);
		}
        return apiGatewayProxyResponseEvent.withBody("resource not found").withHeaders(headers).withStatusCode(200);
    }
}