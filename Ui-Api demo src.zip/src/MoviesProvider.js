import { createContext } from "react";
import { API } from 'aws-amplify';
import { useEffect, useState } from 'react';

const MovieContext=createContext();
function MoviesProvider(props) {
    const apiName="moviesapi";
    const path="/movies";
    const [movies,setMovies]=useState([]);
    const [movie,setMovie]=useState({
        id:"",
      title:"",
      director:""
    })
    const [moviesState,setMoviesState]=useState(false);
    const [showmovies,setShowMovies]=useState(false);
    const [showAddMovieForm,setShowAddMovieForm]=useState(false);
    const [showMovieUpdateForm,setShowMovieUpdateForm]=useState(false);
  
    useEffect(()=>{
      getMovies()
    },[moviesState])
  
    const getMovies=async()=>{
      await API.get(apiName,path)
      .then(data=>setMovies(data))
      .catch(e=>console.log(e))
      setShowMovies(true);
        setShowMovieUpdateForm(false);
        setShowAddMovieForm(false);
    }
  
    const addMovie=async(event)=>{
    event.preventDefault();
      await API.post(apiName,path,{
        body:movie
      })
      .then(data=>{
        console.log(data);
        setMoviesState(!moviesState)
      })
      .catch(e=>console.log(e))

      event.target.reset();
    }
  
    const onChangeHandler=({target:{id,value}})=>{
      setMovie({...movie,[id]:value})
    }
    
    const updateMovieHandler=(movie)=>{
        setMovie(movie);
        setShowMovies(false);
        setShowMovieUpdateForm(true);
    }

    const addMovieHandler=()=>{
        setShowMovies(false);
        setShowAddMovieForm(true);
    }

    const updateMovie=async()=>{
        await API.put(apiName,path,{
            body:movie
        })
        .then(data=>{
            console.log(data);
            setShowMovieUpdateForm(false);
            setShowMovies(true);
        })
        .catch(e=>console.log(e))
    }
    const deleteMovie=async(movie)=>{
        await API.del(apiName,path,{
            body:movie
        })
        .then(data=>{
            setMoviesState(!moviesState);
            console.log(data);
        })
        .catch(e=>console.log(e))
    }
  return (
    <MovieContext.Provider value={{movies,getMovies,addMovie,updateMovie,movie,onChangeHandler,addMovieHandler,showAddMovieForm,
                                    updateMovieHandler,showMovieUpdateForm,showmovies,deleteMovie}}>
      {props.children}
    </MovieContext.Provider>
  )
}

export {MovieContext,MoviesProvider};