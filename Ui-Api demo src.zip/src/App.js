import { useContext } from 'react';
import './App.css';
import AddMovieForm from './custom-components/AddMovieForm';
import ShowMovies from './custom-components/ShowMovies';
import UpdateMovieForm from './custom-components/UpdateMovieForm';
import { MovieContext } from './MoviesProvider';

function App() {
  const {addMovieHandler,showAddMovieForm,showMovieUpdateForm,showmovies,getMovies}=useContext(MovieContext);
  return (
    <div className="App">
      <h1>Movies</h1>
      <button onClick={getMovies}>list-movies</button>
      <button onClick={addMovieHandler}>add movie</button>
      {
        showmovies && (<ShowMovies/>)
      }
      {
        showAddMovieForm && (<AddMovieForm/>)
      }
      {
        showMovieUpdateForm && (<UpdateMovieForm/>)
      }
    </div>
  );
}

export default App;
