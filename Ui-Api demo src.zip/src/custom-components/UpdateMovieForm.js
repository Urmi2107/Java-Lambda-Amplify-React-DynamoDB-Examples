import { useContext } from "react"
import { MovieContext } from "../MoviesProvider"

function UpdateMovieForm() {
    const {movie,updateMovie,onChangeHandler}=useContext(MovieContext);
  return (
    <div>
        <form>
        <label htmlFor='title'>title :</label>
        <input type="text" id='title' value={movie.title} onChange={onChangeHandler}/><br/>
        <label htmlFor='director'>director :</label>
        <input type="text" id='director' value={movie.director} onChange={onChangeHandler}/><br/>
        <button type='button' onClick={updateMovie}>update</button>
      </form>
    </div>
  )
}

export default UpdateMovieForm
