import { Card } from '@aws-amplify/ui-react';
import { useContext } from 'react';
import { MovieContext } from '../MoviesProvider';
export default function ShowMovies() {
    const {movies,updateMovieHandler,deleteMovie}=useContext(MovieContext);
  return (
    <>
        {
        movies.map(movie=>
          <Card style={{backgroundColor:"grey",width:"30%",margin:"1rem auto"}}>
            <h4>{movie.title}</h4>
            <p>{movie.director}</p>
            <button type='button' onClick={()=>{deleteMovie(movie)}}>delete</button>
            <button type='button' onClick={()=>{updateMovieHandler(movie)}}>update</button>
          </Card>
          )
        }
    </>
  )
}
