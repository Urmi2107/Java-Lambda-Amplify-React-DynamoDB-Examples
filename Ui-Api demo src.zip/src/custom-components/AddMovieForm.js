import { useContext } from "react"
import { MovieContext } from "../MoviesProvider"

export default function AddMovieForm() {
    const {onChangeHandler,addMovie}=useContext(MovieContext);
  return (
    <div>
      <form onSubmit={addMovie}>
        <label htmlFor='title'>title :</label>
        <input type="text" id='title' onChange={onChangeHandler}/><br/>
        <label htmlFor='director'>director :</label>
        <input type="text" id='director' onChange={onChangeHandler}/><br/>
        <button type='submit'>add</button>
      </form>
    </div>
  )
}
