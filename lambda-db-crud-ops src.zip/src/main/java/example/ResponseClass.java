/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	STORAGE_MARKETDB_ARN
	STORAGE_MARKETDB_NAME
	STORAGE_MARKETDB_STREAMARN
Amplify Params - DO NOT EDIT */

package example;
        
     public class ResponseClass {
        String id;
        String name;
        int price;

        public ResponseClass() {
        }
        public ResponseClass(String id, String name, int price) {
            this.id = id;
            this.name = name;
            this.price = price;
        }
        public String getId() {
            return id;
        }
        public void setId(String id) {
            this.id = id;
        }
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public int getPrice() {
            return price;
        }
        public void setPrice(int price) {
            this.price = price;
        }
        
        
    }