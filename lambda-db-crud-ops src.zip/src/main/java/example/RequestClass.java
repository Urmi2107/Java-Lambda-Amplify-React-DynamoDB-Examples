/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	STORAGE_MARKETDB_ARN
	STORAGE_MARKETDB_NAME
	STORAGE_MARKETDB_STREAMARN
Amplify Params - DO NOT EDIT */

package example;
        
     public class RequestClass {
        String id;
        String name;
        Number price;
        
        
        public String getName() {
            return name;
        }


        public void setName(String name) {
            this.name = name;
        }


        public Number getPrice() {
            return price;
        }

        public void setPrice(Number price) {
            this.price = price;
        }

        

        public RequestClass(String name, Number price) {
            this.name = name;
            this.price = price;
        }


        public RequestClass() {
        }


        public String getId() {
            return id;
        }


        public void setId(String id) {
            this.id = id;
        }
    }