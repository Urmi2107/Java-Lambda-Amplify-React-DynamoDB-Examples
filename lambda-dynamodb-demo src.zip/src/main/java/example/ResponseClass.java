/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	STORAGE_MOVIES_ARN
	STORAGE_MOVIES_NAME
	STORAGE_MOVIES_STREAMARN
Amplify Params - DO NOT EDIT */

package example;
        
     public class ResponseClass {
        String id;
        String title;
        String director;
        public String getId() {
            return id;
        }
        public void setId(String id) {
            this.id = id;
        }
        public String getTitle() {
            return title;
        }
        public void setTitle(String title) {
            this.title = title;
        }
        public String getDirector() {
            return director;
        }
        public void setDirector(String director) {
            this.director = director;
        }
        public ResponseClass(String id, String title, String director) {
            this.id = id;
            this.title = title;
            this.director = director;
        }
        public ResponseClass() {
        }
        
        
    }