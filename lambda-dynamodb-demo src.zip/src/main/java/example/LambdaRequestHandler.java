/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	STORAGE_MOVIES_ARN
	STORAGE_MOVIES_NAME
	STORAGE_MOVIES_STREAMARN
Amplify Params - DO NOT EDIT */

package example;

import java.util.List;
import java.util.stream.Collectors;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.lambda.runtime.Context; 
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.google.gson.Gson;

public class LambdaRequestHandler{   

    public String handleRequest(RequestClass request, Context context){
		AmazonDynamoDB amazonDynamoDB=AmazonDynamoDBClientBuilder.standard().build();
		Gson gson = new Gson();
		ScanResult scanResult = amazonDynamoDB.scan(new ScanRequest().withTableName(System.getenv("STORAGE_MOVIES_NAME")));
		List<ResponseClass> movieList = scanResult.getItems().stream().map(
			item->new ResponseClass(
				item.get("id").getS(),
				item.get("title").getS(),
				item.get("director").getS()
			)
		)
		.collect(Collectors.toList());
        return gson.toJson(movieList);
    }
}